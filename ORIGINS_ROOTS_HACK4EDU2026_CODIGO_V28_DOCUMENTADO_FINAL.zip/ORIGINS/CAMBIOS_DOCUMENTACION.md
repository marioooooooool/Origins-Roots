# Actualización documental de la entrega V28

**Fecha:** 2026-11-05

## Archivos modificados o añadidos

- `README.md`: sustituida la referencia obsoleta V25 por V28; ampliadas las instrucciones, funciones y limitaciones verificadas con el código.
- `ESTRUCTURA_TECNICA.md`: sustituida la referencia obsoleta V24 por V28; explicada la arquitectura local, lectura de enunciados, datos y simulación.
- `GUIA_DE_COMPROBACION.md`: incorporada una guía de comprobación manual del caso de Amina y de Studio.
- `CAMBIOS_DOCUMENTACION.md`: registro de esta revisión.

## Integridad del código

El archivo `index.html` **no se ha editado** en esta actualización. Hash SHA-256 del HTML de la entrega original y del final:

`1438c234a7dd3c7f4461df2416cf369a8f0d3126a20b0e5818fa8c1b695f69c8`

## Nota sobre capacidades no implementadas

El prototipo utiliza plantillas locales, datos ficticios y una simulación local del modo sin conexión y de su sincronización. La documentación evita atribuirle un backend real, IA generativa conectada o testimonios de campo auténticos.
