# ORIGINS ROOTS — Educación universal, raíces locales

## Entrega de código · Hack4Edu 2026 · Versión V28

**ORIGINS ROOTS** es un prototipo web educativo que convierte historias y conocimientos culturales de comunidades ficticias de demostración en experiencias de aprendizaje para niños, con apoyo de Ori y una zona de gestión docente denominada **ORIGINS Studio**.

**Punto de entrada:** `index.html`. El proyecto está diseñado como un único archivo HTML autocontenido con CSS, JavaScript y recursos visuales integrados. **No es necesario instalar dependencias ni configurar un servidor** para explorar el prototipo en un navegador moderno.

## Cómo ejecutarlo

1. Descomprime el archivo ZIP.
2. Abre la carpeta `ORIGINS`.
3. Haz doble clic en `index.html` y ábrelo con Google Chrome (preferentemente en ordenador).
4. En la portada, pulsa **Explorar comunidades** o **ORIGINS Studio**.
5. Para una demostración limpia, utiliza una ventana normal del navegador, no incógnito, y prueba primero el sonido.

Si un navegador restringe el almacenamiento local al abrir archivos mediante `file://`, puedes abrir la misma carpeta en un pequeño servidor local (opcional): desde una terminal situada en `ORIGINS`, ejecuta `python3 -m http.server 8000` y visita `http://localhost:8000`. Python solo se necesita para este método alternativo.

## Datos de acceso de demostración

| Perfil | Acceso |
|---|---|
| Alumno | Comunidad → avatar → PIN de prueba `1234` |
| Docentes y organizaciones | Botón **ORIGINS Studio** → contraseña de prueba `ORIGINS2026` |

Las cuentas y claves son exclusivamente ilustrativas. La contraseña de Studio es una barrera de interfaz del cliente, **no un mecanismo seguro de autenticación en producción**.

## Comunidades de demostración

- **Nalari (Senegal):** recorrido educativo de Amina, en francés, con agricultura, huerto de Mariam, mercado y Memoria viva.
- **Bahía Marea (Colombia):** recorrido en español con referencias al entorno costero y actividades contextualizadas.

**Aviso:** los personajes, relatos, testimonios y datos de estas comunidades del ejemplo son ficticios. No deben presentarse como casos reales verificados externamente.

## Funciones incluidas en la V28

1. **ORIGINS Learn:** selección de comunidad y avatar, mapa de aventuras, juegos de cálculo y resolución de situaciones vinculadas al contexto local.
2. **Ori:** acompañamiento, pistas previstas en las actividades y síntesis de voz mediante las funciones de voz del navegador; controles de voz disponibles según el dispositivo.
3. **Lectura de enunciados (novedad V28):** botón **«Écouter l’énoncé» / «Escuchar enunciado»** en las fases compatibles de exploración, huerto, mercado y salud; utiliza la síntesis de voz y el idioma configurado. Lee el enunciado, no las soluciones.
4. **Cierre educativo y reflexión:** resumen de lo aprendido y respuesta personal del estudiante al terminar una misión.
5. **Memoria viva:** cuentos ilustrados, lectura de historias locales, escritura creativa de capítulos y revisión desde Studio.
6. **Simulación de trabajo sin conexión:** opción de activar el modo de demostración sin conexión, guardar eventos y observar los resultados pendientes.
7. **Sincronización local simulada:** al reactivar la conexión de demostración, la cola pendiente se incorpora a un registro local visible en Studio; **no transmite datos entre dispositivos ni a un servidor externo**.
8. **ORIGINS Studio:** fichas de comunidades, cuestionarios y testimonios con estados de aprobación, generación contextualizada mediante plantillas, seguimiento de alumnado y registros de la demostración.

## Demostración recomendada: caso de Amina

1. Entra en **Nalari** y selecciona **Amina** con el PIN `1234`.
2. Escucha la bienvenida de Ori en francés y observa las opciones de voz.
3. Abre **el huerto de Mariam** y utiliza **«Écouter l’énoncé»** para escuchar las instrucciones.
4. Resuelve las dos fases: **4 parcelas de maíz, 3 de mijo y 5 libres**; después, **4 semillas** conservadas.
5. Muestra la felicitación final y guarda una reflexión personal en francés.
6. Abre otra actividad, activa **«Simuler hors connexion»** y registra respuestas; observa el contador de pendientes.
7. Pulsa **«Rétablir la connexion»** y comprueba la recepción local de los resultados.
8. Visita **Memoria viva** y el apartado creativo.
9. Entra en **ORIGINS Studio**, revisa **Comunidades**, **Memoria viva** y **Seguimiento**.

## Limitaciones y funcionamiento sin Internet

- La app incorpora HTML, estilos, scripts y recursos visuales en un único archivo, por lo que sus partes locales pueden abrirse sin un servidor de aplicación.
- La lectura de voz depende del navegador y de las voces instaladas. Para usarla sin acceso a Internet, es recomendable disponer de una voz local compatible; algunas voces pueden requerir servicios externos.
- El control «sin conexión» y el «registro sincronizado» son una **simulación local en el mismo navegador**; todavía no existe backend, autenticación real, servidor remoto ni sincronización multi-dispositivo.
- El generador de aventuras que muestra Studio utiliza plantillas y lógica local del prototipo. **No conecta actualmente con una API de IA generativa**.
- El progreso y las aportaciones se guardan en `localStorage`; los controles de acceso de Studio usan también `sessionStorage`. Evita introducir información personal real, especialmente de menores.
- Esta versión **no incorpora el experimento de pistas adaptativas de Ori de V23**. Sí conserva las funciones de acompañamiento previstas y el cierre educativo con reflexión.

## Documentación incluida

- `index.html`: aplicación y código fuente íntegros, **sin modificar** respecto a la V28 recibida.
- `README.md`: este documento, actualizado para V28.
- `ESTRUCTURA_TECNICA.md`: arquitectura, almacenamiento, módulos y limitaciones.
- `GUIA_DE_COMPROBACION.md`: recorrido manual recomendado para revisar la entrega.
- `CAMBIOS_DOCUMENTACION.md`: registro de los cambios de documentación y garantía de integridad del código.

La demostración es un **prototipo funcional**, no un servicio desplegado ni un sistema preparado para uso real con datos de menores.
