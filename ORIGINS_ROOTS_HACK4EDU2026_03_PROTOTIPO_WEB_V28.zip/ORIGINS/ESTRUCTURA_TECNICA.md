# Estructura técnica y componentes de ORIGINS V24

- **Interfaz y navegación:** HTML, CSS y JavaScript en `index.html`, diseño adaptable a móvil y escritorio.
- **Datos locales:** persistencia de progreso y aportaciones en `localStorage` del navegador.
- **Áreas de usuario:** ORIGINS Learn para alumnos y ORIGINS Studio para gestión educativa.
- **Contenido:** dos comunidades de demostración; juegos de cálculo, toma de decisiones y reflexión ligados a su contexto.
- **Memoria viva:** cuentos ilustrados y nuevas aportaciones por alumno; publicación de capítulos mediante revisión en Studio.
- **Audio de Ori:** Web Speech API (síntesis de voz) y selección de voces disponibles.
- **Sin conexión:** simulación de desconexión, cola de eventos y recepción local, con controles de sincronización demostrativos.
- **Privacidad/seguridad:** datos de demostración en el navegador; no se debe introducir información personal real de menores en este prototipo.

No se incluyen dependencias externas. Para extender el sistema a un despliegue multi-dispositivo serían necesarios autenticación y almacenamiento seguros en un servicio backend, sincronización por red y un mecanismo robusto de instalación offline.


### Narración de enunciados
El botón de lectura reutiliza SpeechSynthesis, la voz/idioma configurados de Ori y el contenido textual visible de cada fase. No lee ni revela opciones de respuesta, pistas o resultados.
