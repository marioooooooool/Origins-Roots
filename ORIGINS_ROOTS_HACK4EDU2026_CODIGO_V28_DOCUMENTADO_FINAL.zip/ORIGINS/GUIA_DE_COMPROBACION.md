# Guía breve de comprobación de la entrega · V28

Esta guía permite que un evaluador reproduzca un recorrido representativo. **Las comprobaciones funcionales deben ejecutarse en el navegador del evaluador**; la revisión estática del código no sustituye a estas pruebas manuales.

## Preparación

1. Descomprimir ZIP y abrir `ORIGINS/index.html` en Chrome.
2. Abrir en ventana normal (no incógnito), activar audio y comprobar que el navegador ofrece voces en francés.
3. Si ya se utilizó previamente, restablecer datos de demostración desde las opciones disponibles de Studio para obtener un escenario limpio.

## Caso de prueba: Amina

| Paso | Acción | Resultado esperado |
|---|---|---|
| 1 | Explorar comunidades → Nalari → Amina → PIN `1234` | Acceso al mapa, idioma francés y bienvenida de Ori. |
| 2 | Abrir opciones de voz y activar Ori | La interfaz ofrece controles de voz; síntesis audible si el navegador dispone de voces compatibles. |
| 3 | Entrar al huerto de Mariam | Se muestra la primera fase del ejercicio. |
| 4 | Pulsar `Écouter l’énoncé` | Se escucha el texto instructivo de la fase, sin leer la respuesta. |
| 5 | Repartir 12 parcelas: 4 de maíz, 3 de mijo y 5 libres | Se completa la fase de reparto. |
| 6 | Segunda fase: semillas disponibles 22; usadas 4×3 + 3×2 | Respuesta correcta: **4 semillas conservadas**. |
| 7 | Completar el reto y escribir una reflexión | Aparecen felicitación y resumen; la reflexión se puede registrar. |
| 8 | Abrir otra actividad y pulsar `Simuler hors connexion` | El prototipo se marca como desconectado. |
| 9 | Registrar respuestas y comprobar pendientes | Aumenta la cola de eventos de demostración. |
| 10 | Pulsar `Rétablir la connexion` | Los eventos pasan al registro recibido local; cola pendiente queda vacía si no hay error. |
| 11 | Visitar Memoria viva y su área creativa | Se muestran historias ilustradas y la opción de aportar un capítulo. |
| 12 | Entrar en Studio con `ORIGINS2026` | Acceso a los paneles de administración de demostración. |
| 13 | Abrir Seguimiento y Sincronización | Indicadores y eventos almacenados de Amina, en el mismo navegador. |
| 14 | Explorar Comunidades, testimonios y su revisión | Formularios, datos y condiciones de aprobación de contenido local. |

## Criterios de transparencia

- **V28**: lectura en voz alta de enunciados, junto a los componentes educativos existentes.
- **Offline**: la interfaz simula la conectividad; **no hay servidor** ni sincronización real entre equipos.
- **IA**: las actividades del prototipo se apoyan en plantillas; no se está llamando a una IA generativa.
- **Datos**: todas las comunidades, personajes y testimonios de ejemplo son ficticios. No usar información real de menores.

## Si no funciona el audio

Revisar el volumen, la voz configurada y las voces instaladas. Algunas voces necesitan acceso a red o no están disponibles en todos los dispositivos. Los ejercicios pueden utilizarse sin la narración.
