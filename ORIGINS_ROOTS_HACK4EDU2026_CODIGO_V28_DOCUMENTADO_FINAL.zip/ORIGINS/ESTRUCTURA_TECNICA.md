# ORIGINS ROOTS · Estructura técnica del prototipo V28

**Fecha de documentación:** 5 de noviembre de 2026  
**Modalidad:** aplicación de demostración web estática, autocontenida.  
**Código principal:** `index.html` (HTML5, CSS3 y JavaScript, sin bibliotecas externas obligatorias).

## 1. Arquitectura general

El proyecto se distribuye en un **único documento HTML** con estilos, scripts y recursos visuales embebidos. El navegador ejecuta la lógica de interfaz y de los ejercicios. No hay servicio backend, base de datos central ni peticiones `fetch()` a una API de aplicación.

Los dos ámbitos de uso están implementados en el mismo archivo:

- **ORIGINS Learn:** experiencia del alumno (comunidad, avatar, PIN de prueba, mapa de misiones, actividades, Ori y Memoria viva).
- **ORIGINS Studio:** interfaz de organizaciones y docentes (información de comunidades, testimonios y validación editorial, generación local mediante plantillas, seguimiento, sincronización simulada y revisión de relatos).

## 2. Modelo educativo y comunidades

Las comunidades iniciales se cargan con datos de ejemplo definidos dentro de JavaScript: **Nalari, Senegal** (francés) y **Bahía Marea, Colombia** (español). Incluyen descripción, historia, medios de vida, recursos, protagonistas y actividades ilustrativas. Son **ejemplos ficticios**.

Studio contiene formularios para registrar el contexto cultural de nuevas comunidades. El asistente de perfil contempla identidad, historia, economía, cultura, recursos, testimonios y revisión. Las aportaciones locales contemplan condiciones de consentimiento y de aprobación editorial en el prototipo.

El generador de aventuras usa **plantillas y reglas locales** para contextualizar ejemplos; **no llama a un modelo generativo de IA por API**.

## 3. Actividades y aprendizaje

Las misiones incluyen escenarios de exploración, huerto, mercado, salud y otros recorridos según la comunidad. Las interacciones se resuelven en JavaScript, y se registran eventos de intentos, ayudas, finalizaciones y reflexiones de los alumnos.

Una de las experiencias de Nalari es **el huerto de Mariam**: reparto de 12 parcelas y cálculo de semillas. El cierre de la misión muestra lo aprendido, ofrece felicitación y permite guardar una **reflexión personal** que puede consultarse desde el área docente.

La generación de pistas adaptativas experimentada en V23 **no forma parte de esta V28**; se mantiene el comportamiento de acompañamiento de Ori previsto en la rama seleccionada.

## 4. Accesibilidad y voz (V28)

La voz de Ori se basa en la **Web Speech API / `speechSynthesis`** del navegador. Las opciones y voces concretas dependen del sistema operativo y del navegador.

La mejora de V28 añade el botón **«Escuchar enunciado» / «Écouter l’énoncé»** en pantallas de misión compatibles (`explore`, `garden`, `market` y `health`). El sistema obtiene las instrucciones visibles de la fase actual y las reproduce en el idioma y la voz elegidos. **No reproduce las respuestas, las pistas ni los resultados** al pulsar este botón.

La reproducción requiere una acción explícita del usuario. En caso de ausencia de soporte de síntesis, la interfaz muestra un aviso. Para voz completamente local sin Internet, deben estar instaladas voces que funcionen offline.

## 5. Persistencia de datos

- **`localStorage`:** estado de la demostración, avance, aportaciones, configuración y registros locales.
- **`sessionStorage`:** sesión de acceso de Studio durante la sesión de navegador.
- **Datos iniciales:** se crean mediante datos de ejemplo incorporados al propio HTML.

Estos mecanismos son apropiados para una **maqueta local**, pero no equivalen a una base de datos compartida o un sistema de cuentas seguro. Los datos pueden perderse si se limpian los datos del navegador.

## 6. Simulación de conectividad y sincronización

La barra superior permite **simular una desconexión**. Durante la desconexión simulada, el prototipo conserva en `localStorage` los eventos educativos en una cola de pendientes. Cuando se restaura la conexión de demostración, se trasladan al registro de eventos recibidos, también almacenado localmente. Studio presenta esos registros para el seguimiento educativo.

Este comportamiento permite demostrar continuidad de uso y trazabilidad en un mismo dispositivo. **No implementa un envío real por red, sincronización entre dispositivos ni persistencia centralizada en un servidor**. Tampoco incorpora un service worker para instalación como PWA.

## 7. Memoria viva y seguimiento

**Memoria viva** combina relatos ilustrados, lectura y creatividad del alumnado. Las nuevas aportaciones pasan por un flujo de revisión antes de considerarse publicables en la demostración.

En **Seguimiento**, Studio muestra indicadores de actividades finalizadas, intentos, ayudas y reflexiones, además de la información local procedente del registro de eventos. No hay panel analítico conectado a un backend.

## 8. Seguridad, privacidad y límites

- Las claves `1234` y `ORIGINS2026` son **credenciales de demostración**, no aptas para producción.
- La validación de Studio ocurre en el **cliente**; no existe autenticación de usuarios ni autorización robusta mediante servidor.
- **No introducir datos reales de menores** ni documentación privada en esta versión.
- Los testimonios incluidos en las comunidades de ejemplo son ficticios; la validación y el consentimiento del prototipo representan un flujo editorial, no certificación externa.
- Para un despliegue real harían falta servidor seguro, permisos por rol, gestión de consentimientos, bases de datos y sincronización multi-dispositivo, medidas de protección de menores y pruebas adicionales.

## 9. Dependencias y ejecución

La aplicación distribuida en `index.html` no requiere instalar bibliotecas ni ejecutar un build. Basta un navegador moderno con JavaScript y almacenamiento local disponibles. Se recomienda **Google Chrome** y verificar las voces antes de mostrar la demo. Si hay restricciones al abrir `file://`, se puede servir la carpeta localmente usando `python3 -m http.server 8000` y visitando `http://localhost:8000`.

**Verificaciones técnicas realizadas para esta entrega documental:** HTML analizable con el parser estándar de Python y bloque JavaScript válido según `node --check`. Esto no sustituye una batería completa de pruebas funcionales en varios navegadores.
