# ORIGINS — Educación universal, raíces locales

## Prototipo de demostración (V25)

Proyecto educativo orientado a niños de primaria, contextualizado en las historias y los conocimientos de cada comunidad.

**Comunidades de ejemplo**
- Nalari, Senegal: huerto, matemáticas y Memoria viva; experiencia del alumno en francés.
- Bahía Marea, Colombia: pesca responsable, matemáticas y Memoria viva; experiencia del alumno en español.

## Cómo ejecutar

1. Descomprime el ZIP.
2. Abre `index.html` con Google Chrome o un navegador moderno.
3. No hace falta instalar bibliotecas ni lanzar un servidor para esta demostración.

**Acceso a alumnos:** seleccionar una comunidad y un avatar; PIN de prueba: `1234`.

**ORIGINS Studio (docentes y ONG):** contraseña de demostración: `ORIGINS2026`.

## Funcionalidades incluidas

- Dos comunidades y perfiles de alumnos.
- Aventuras con actividades contextualizadas, mapas e interacción.
- Ori con indicaciones, pistas originales y síntesis de voz del navegador.
- Libro vivo de la comunidad: historias ilustradas, escritura de capítulos, revisión docente y exportación.
- Resumen final personalizado de aprendizaje con reflexión del alumno (incorporado en V25).
- Modo de conexión simulado; registro de actividades, cola de eventos y sincronización local de demostración.
- Seguimiento docente en ORIGINS Studio y posibilidad de reiniciar los resultados de prueba.

## Cómo está hecho

Todo el código de esta versión se encuentra en `index.html`: HTML, CSS y JavaScript integrados, junto a los recursos visuales embebidos. Los resultados se guardan en el almacenamiento local del navegador.

**Alcance del prototipo:** la generación de aventuras se apoya en plantillas y lógica local; no hay API de inteligencia artificial generativa conectada. La desconexión y la sincronización con Studio se simulan en el mismo navegador; no existe un servidor remoto ni transmisión de resultados entre dispositivos. La contraseña protege la interfaz de demostración, no es una solución de autenticación para producción.

La disponibilidad y la naturalidad de la voz dependen de las voces instaladas y de las capacidades del navegador. Se recomienda hacer una prueba en el equipo de presentación.

## Versión seleccionada

Esta entrega corresponde a la V25: **mantiene el cierre educativo personalizado, pero no incluye las nuevas pistas adaptativas de Ori que se probaron en V23**.

Las historias y los personajes de las comunidades de ejemplo son ficticios y sirven para demostrar la idea de ORIGINS.


## Accesibilidad: enunciados narrados (V28)
En las misiones de exploración, huerto, pesca, mercado y salud hay un botón «Escuchar enunciado» (en francés «Écouter l’énoncé») para reproducir las instrucciones de la fase actual. Usa la voz de Ori y la síntesis del navegador. Se activa mediante clic, sin conexión a una API; para funcionamiento realmente sin Internet es necesario contar con voces locales instaladas.
